def main():
    print("It's alive!")